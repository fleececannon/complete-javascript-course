import { handleSubmit } from "../src/client/js/formHandler";

test('submit test', () => {
    expect(handleSubmit).toBeDefined();
  });