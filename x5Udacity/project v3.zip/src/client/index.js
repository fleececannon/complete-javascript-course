import { handleSubmit } from './js/app';
import { getWeather } from './js/app';
// import { isURL } from './js/isURL';

import './styles/index.scss';

export { handleSubmit, getWeather};
